# zxing-spring-boot-starter

#### 介绍
zxing-spring-boot-starter支持渲染二维码、渲染带logo二维码、解析二维码内容

#### 软件架构
基于spring-boot2.1.9.RELEASE、com.google.zxing3.3.3
```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>2.1.9.RELEASE</version>
    <relativePath/> <!-- lookup parent from repository -->
</parent>
```
```xml
<dependency>
    <groupId>com.google.zxing</groupId>
    <artifactId>core</artifactId>
    <version>3.3.3</version>
</dependency>
```
#### 安装教程

1.  导入pom依赖
```xml
<dependency>
  <groupId>com.kuisama</groupId>
  <artifactId>zxing-spring-boot-starter</artifactId>
  <version>1.0.0.RELEASE</version>
</dependency>
```
2.  配置application.yml
```text
有默认属性值，可不配置
```
```yaml
zxing:
    width: 默认200
    height: 默认200
```
#### 使用说明
```java
   package com.kuisama.zxing;
   
   import com.google.zxing.NotFoundException;
   import com.google.zxing.WriterException;
   import org.springframework.beans.factory.annotation.Autowired;
   import org.springframework.boot.SpringApplication;
   import org.springframework.boot.autoconfigure.SpringBootApplication;
   import org.springframework.web.bind.annotation.GetMapping;
   import org.springframework.web.bind.annotation.RestController;
   
   import java.io.File;
   import java.io.IOException;
   
   /**
    * Hello world!
    *
    * @author chowk
    */
   @SpringBootApplication
   @RestController
   public class ZxingStarter {
       @Autowired
       private ZxingHandler zxingHandler;

       public static void main(String[] args) {
           SpringApplication.run(ZxingStarter.class, args);
       }

       /**
        * 渲染
        *
        * @throws WriterException
        * @throws IOException
        */
       @GetMapping("/get")
       public void get() throws IOException, WriterException {
           zxingHandler.render("www.baidu.com");
       }
   
       /**
        * 渲染带logo
        *
        * @throws WriterException
        * @throws IOException
        */
       @GetMapping("/getwithlogo")
       public void getLogo() throws IOException, WriterException {
           zxingHandler.render("www.baidu.com", "src/resources/img/", "timg.jpg");
       }
   
       /**
        * 解析二维码内容
        *
        * @throws WriterException
        * @throws IOException
        * @throws NotFoundException
        */
       @GetMapping("/analysis")
       public String analysis() throws IOException, NotFoundException {
           return zxingHandler.getText(new File("src/main/resources/img/" + "response.jpeg"));
       }
   }
```


