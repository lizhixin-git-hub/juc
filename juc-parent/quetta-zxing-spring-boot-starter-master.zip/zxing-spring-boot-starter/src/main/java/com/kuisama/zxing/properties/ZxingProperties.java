package com.kuisama.zxing.properties;

import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * zxing二维码配置
 *
 * @author kuisama
 */
@Component
@ConfigurationProperties(prefix = "zxing")
@Data
public class ZxingProperties {
    /**
     * 宽度,默认200.
     */
    private int width = 200;

    /**
     * 高度,默认200.
     */
    private int height = 200;

    /**
     * 图片格式（jpeg/jpg/png）,默认png.
     */

    private String format = "png";

    /**
     * 编码,默认UTF_8.
     */
    private Charset charset = StandardCharsets.UTF_8;

    /**
     * 容错等级 L、M、Q、H ,其中 L为最低, H为最高,默认H.
     */
    private ErrorCorrectionLevel errorLevel = ErrorCorrectionLevel.H;

    /**
     * 边距,默认2.
     */
    private int margin = 2;
}
