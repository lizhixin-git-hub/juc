package com.kuisama.zxing.autoconfigure;

import com.google.zxing.EncodeHintType;
import com.kuisama.zxing.properties.ZxingProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * zxing自动配置
 *
 * @author kuisama
 */
@Configuration
@EnableConfigurationProperties(ZxingProperties.class)
@ConditionalOnProperty(prefix = "zxing", value = "true", matchIfMissing = true)
public class ZxingConfiguration {
    @Autowired
    private ZxingProperties properties;

    @Bean("hints")
    public Map<EncodeHintType, Object> hints() {
        Map<EncodeHintType, Object> hintsMap = new HashMap<>(3);
        hintsMap.put(EncodeHintType.CHARACTER_SET, properties.getCharset());
        hintsMap.put(EncodeHintType.ERROR_CORRECTION, properties.getErrorLevel());
        hintsMap.put(EncodeHintType.MARGIN, properties.getMargin());
        return hintsMap;
    }
}
