package com.kuisama.zxing;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.kuisama.zxing.properties.ZxingProperties;
import com.kuisama.zxing.util.MatrixToImageWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * zxing二维码Handler
 *
 * @author kuisama
 */
@Component
public class ZxingHandler {
    /**
     * 二维码参数
     */
    @Autowired
    private Map<EncodeHintType, Object> hints;

    @Autowired
    private HttpServletResponse response;

    @Autowired
    private ZxingProperties zxingProperties;

    /**
     * 正常二维码,返回BufferedImage
     *
     * @param content 内容
     * @throws WriterException
     */
    public BufferedImage toBufferedImage(String content) throws WriterException {
        BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, zxingProperties.getWidth(),
                zxingProperties.getHeight(), hints);
        return MatrixToImageWriter.toBufferedImage(bitMatrix);

    }

    /**
     * 正常二维码,响应HttpServletResponse
     *
     * @param content 内容
     * @throws IOException
     * @throws WriterException
     */
    public void render(String content) throws IOException, WriterException {
        BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, zxingProperties.getWidth(),
                zxingProperties.getHeight(), hints);
        MatrixToImageWriter.writeToStream(bitMatrix, zxingProperties.getFormat(), response);

    }

    /**
     * 带logo的二维码
     *
     * @param content  内容
     * @param logoPath 文件路径
     * @param logoName 文件名
     * @throws IOException
     * @throws WriterException
     */
    public void render(String content, String logoPath, String logoName) throws IOException, WriterException {
        BufferedImage matrixImage = toBufferedImage(content);
        File logoFile = new File(logoPath.concat(logoName));
        if (!logoFile.exists()) {
            System.err.println("" + logoPath + "   the file is not exist！");
            return;
        }
        //  读取二维码图片，并构建绘图对象
        Graphics2D g2 = matrixImage.createGraphics();
        int matrixWidth = matrixImage.getWidth();
        int matrixHeigh = matrixImage.getHeight();
        // 读取Logo图片
        BufferedImage logo = ImageIO.read(logoFile);
        // 开始绘制图片
        g2.drawImage(logo, matrixWidth / 5 * 2, matrixHeigh / 5 * 2, matrixWidth / 5, matrixHeigh / 5, null);
        BasicStroke stroke = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        // 设置笔画对象
        g2.setStroke(stroke);
        // 指定弧度的圆角矩形
        RoundRectangle2D.Float round = new RoundRectangle2D.Float(matrixWidth / 5 * 2, matrixHeigh / 5 * 2,
                matrixWidth / 5, matrixHeigh / 5, 20, 20);
        g2.setColor(Color.white);
        // 绘制圆弧矩形
        g2.draw(round);
        // 设置logo 有一道灰色边框
        BasicStroke stroke2 = new BasicStroke(1, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        // 设置笔画对象
        g2.setStroke(stroke2);
        RoundRectangle2D.Float round2 = new RoundRectangle2D.Float(matrixWidth / 5 * 2 + 2, matrixHeigh / 5 * 2 + 2,
                matrixWidth / 5 - 4, matrixHeigh / 5 - 4, 20, 20);
        g2.setColor(new Color(128, 128, 128));
        // 绘制圆弧矩形
        g2.draw(round2);
        g2.dispose();
        matrixImage.flush();
        MatrixToImageWriter.writeToStream(matrixImage, zxingProperties.getFormat(), response);
    }

    /**
     * 解析二维码内容
     *
     * @param file 文件
     * @throws IOException
     * @throws NotFoundException
     */
    public String getText(File file) throws IOException, NotFoundException {
        MultiFormatReader formatReader = new MultiFormatReader();
        // 读取指定的二维码文件
        BufferedImage bufferedImage = ImageIO.read(file);
        BinaryBitmap binaryBitmap = new BinaryBitmap(
                new HybridBinarizer(new BufferedImageLuminanceSource(bufferedImage)));
        // 定义二维码参数
        Map<DecodeHintType, ?> analysis = new HashMap<>(1);
        hints.put(EncodeHintType.CHARACTER_SET, zxingProperties.getCharset());
        com.google.zxing.Result result = formatReader.decode(binaryBitmap, analysis);
        // 输出相关的二维码信息
        bufferedImage.flush();
        return result.getText();
    }
}
